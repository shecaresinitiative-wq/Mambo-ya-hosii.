try { require('dotenv').config(); } catch (e) { /* optional */ }
const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const PDFDocument = require('pdfkit');
const nodemailer = require('nodemailer');
const moment = require('moment');
const axios = require('axios'); // PayHero API client
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;

// ========== CONFIG ==========
const APPLICATION_FEE_KES = 1200; // fixed amount (KSh) - intentionally not configurable via environment
const ADMIN_KEY = process.env.ADMIN_KEY || 'Brayo123';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const UPLOADS_DIR = process.env.UPLOADS_DIR || path.join(__dirname, 'uploads');
const LETTERS_DIR = process.env.LETTERS_DIR || path.join(__dirname, 'generated-letters');
const PENDING_EXPIRY_MS = parseInt(process.env.PENDING_EXPIRY_MS || String(15 * 60 * 1000), 10); // 15 min
const APPS_FILE = path.join(DATA_DIR, 'applications.json');
const PENDING_FILE = path.join(DATA_DIR, 'pending-payments.json');
const COUNTER_FILE = path.join(DATA_DIR, 'counter.json');

// Ensure directories exist
[DATA_DIR, UPLOADS_DIR, LETTERS_DIR].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// ========== PERSISTENCE ==========
function atomicWrite(filePath, data) {
  const tmp = filePath + '.tmp.' + process.pid;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, filePath);
}

function loadJson(filePath, fallback) {
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }
  } catch (e) {
    console.error('Failed to load', filePath, e.message);
  }
  return fallback;
}

let applications = loadJson(APPS_FILE, []);
let pendingPayments = loadJson(PENDING_FILE, {});
let applicationCounter = loadJson(COUNTER_FILE, { value: 1000 }).value;

function saveApplications() {
  atomicWrite(APPS_FILE, applications);
}
function savePending() {
  atomicWrite(PENDING_FILE, pendingPayments);
}
function saveCounter() {
  atomicWrite(COUNTER_FILE, { value: applicationCounter });
}

// Clean expired pending payments periodically
setInterval(() => {
  const now = Date.now();
  let changed = false;
  for (const [id, p] of Object.entries(pendingPayments)) {
    const created = new Date(p.createdAt || 0).getTime();
    if (now - created > PENDING_EXPIRY_MS) {
      delete pendingPayments[id];
      changed = true;
    }
  }
  if (changed) savePending();
}, 60 * 1000);

// ========== MIDDLEWARE ==========
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Do NOT publicly serve letters or uploads — protected routes only
// Security headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});

// ========== HOSPITAL DATA ==========
const hospitalsByRegion = {
  "Mombasa": [
    "Aga Khan Hospital Mombasa",
    "The Mombasa Hospital",
    "Premier Hospital (Nyali)"
  ],
  "Kisumu": [
    "Aga Khan Hospital Kisumu",
    "Avenue Hospital Kisumu",
    "Kisumu Specialists Hospital"
  ],
  "Nairobi": [
    "Aga Khan University Hospital Nairobi",
    "The Nairobi Hospital",
    "MP Shah Hospital"
  ],
  "Eldoret": [
    "Mediheal Hospital & Fertility Centre",
    "Eldoret Hospital",
    "Tophill Hospital"
  ],
  "Bungoma": [
    "LifeCare Hospitals Bungoma",
    "Bungoma West Hospital",
    "New Elgon View Medical Cottage"
  ]
};

const hospitalBranding = {
  "Aga Khan Hospital Mombasa": {
    name: "Aga Khan Hospital Mombasa",
    color: "#8B0000",
    address: "Vanga Road, Kizingo, Mombasa",
    phone: "+254 722 205 110",
    email: "hr.mombasa@agakhanhospitals.org"
  },
  "The Mombasa Hospital": {
    name: "The Mombasa Hospital",
    color: "#003366",
    address: "Transport Road, Ganjoni, Mombasa",
    phone: "+254 41 231 2191",
    email: "hr@mombasahospital.co.ke"
  },
  "Premier Hospital (Nyali)": {
    name: "Premier Hospital",
    color: "#006666",
    address: "Links Road, Nyali, Mombasa",
    phone: "+254 41 501 1500",
    email: "careers@premierhospital.co.ke"
  },
  "Aga Khan Hospital Kisumu": {
    name: "Aga Khan Hospital Kisumu",
    color: "#8B0000",
    address: "Otieno Oyoo Street, Kisumu",
    phone: "+254 722 203 622",
    email: "hr.kisumu@agakhanhospitals.org"
  },
  "Avenue Hospital Kisumu": {
    name: "Avenue Hospital Kisumu",
    color: "#1a5276",
    address: "Kibuye Market, Kisumu-Kakamega Road",
    phone: "+254 711 060 000",
    email: "hr.kisumu@avenuehealthcare.com"
  },
  "Kisumu Specialists Hospital": {
    name: "Kisumu Specialists Hospital",
    color: "#145a32",
    address: "RIAT Junction, Kisumu-Kakamega Highway",
    phone: "+254 780 154 131",
    email: "recruitment@kisumuspecialists.co.ke"
  },
  "Aga Khan University Hospital Nairobi": {
    name: "Aga Khan University Hospital Nairobi",
    color: "#8B0000",
    address: "3rd Parklands Avenue, Nairobi",
    phone: "+254 20 366 2000",
    email: "hr.nairobi@aku.edu"
  },
  "The Nairobi Hospital": {
    name: "The Nairobi Hospital",
    color: "#1a5276",
    address: "Argwings Kodhek Road, Upper Hill, Nairobi",
    phone: "+254 20 284 5000",
    email: "recruitment@nbihosp.org"
  },
  "MP Shah Hospital": {
    name: "MP Shah Hospital",
    color: "#6c3483",
    address: "Shivaji Road, Parklands, Nairobi",
    phone: "+254 20 4291 100",
    email: "hr@mpshahhosp.org"
  },
  "Mediheal Hospital & Fertility Centre": {
    name: "Mediheal Hospital & Fertility Centre",
    color: "#1a5276",
    address: "Nandi Road, Eldoret",
    phone: "+254 723 578 895",
    email: "careers.eldoret@medihealgroup.com"
  },
  "Eldoret Hospital": {
    name: "Eldoret Hospital",
    color: "#922b21",
    address: "Makasembo Road, Eldoret",
    phone: "+254 722 231 438",
    email: "hr@eldorethospital.com"
  },
  "Tophill Hospital": {
    name: "Tophill Hospital",
    color: "#1b4f72",
    address: "Garden Road, Elgon View, Eldoret",
    phone: "+254 782 900 090",
    email: "recruitment@tophillhospital.co.ke"
  },
  "LifeCare Hospitals Bungoma": {
    name: "LifeCare Hospitals Bungoma",
    color: "#0e6655",
    address: "Mumias Road, next to Christ the King Church, Bungoma",
    phone: "+254 730 950 000",
    email: "hr.bungoma@lchafrica.com"
  },
  "Bungoma West Hospital": {
    name: "Bungoma West Hospital",
    color: "#1a5276",
    address: "Malaba-Eldoret Highway, Kanduyi, Bungoma",
    phone: "+254 724 278 870",
    email: "careers@bungomawesthospital.co.ke"
  },
  "New Elgon View Medical Cottage": {
    name: "New Elgon View Medical Cottage",
    color: "#145a32",
    address: "Mumias - Bungoma Road, Bungoma",
    phone: "+254 55 30698",
    email: "hr@elgonviewmedical.co.ke"
  }
};

const positions = [
  "Registered Nurse", "Enrolled Nurse", "Clinical Officer",
  "Medical Doctor / Medical Officer", "Laboratory Technologist",
  "Pharmacy Technologist", "Radiographer / Imaging Technologist",
  "Physiotherapist", "Health Records Officer", "Hospital Administrator",
  "HR Officer", "Accountant / Finance Officer", "Cleaner / Housekeeping",
  "Security Officer", "Driver / Ambulance Driver", "Other"
];

// ========== MULTER ==========
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /pdf|doc|docx/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype) || file.mimetype.includes('document') || file.mimetype.includes('pdf');
    if (ext || mime) return cb(null, true);
    cb(new Error('Only PDF, DOC, DOCX files are allowed'));
  }
});

// ========== ADMIN RATE LIMIT ==========
const adminAttempts = {}; // ip → { count, lockedUntil }
const ADMIN_MAX_ATTEMPTS = 5;
const ADMIN_LOCK_MS = 15 * 60 * 1000;

function checkAdminAuth(req, res) {
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const entry = adminAttempts[ip] || { count: 0, lockedUntil: 0 };
  if (Date.now() < entry.lockedUntil) {
    res.status(429).json({ success: false, message: 'Too many failed attempts. Try again later.' });
    return false;
  }
  const key = req.headers['x-admin-key'] || req.query.key || '';
  if (key !== ADMIN_KEY) {
    entry.count += 1;
    if (entry.count >= ADMIN_MAX_ATTEMPTS) {
      entry.lockedUntil = Date.now() + ADMIN_LOCK_MS;
      entry.count = 0;
    }
    adminAttempts[ip] = entry;
    res.status(401).json({ success: false, message: 'Unauthorized' });
    return false;
  }
  adminAttempts[ip] = { count: 0, lockedUntil: 0 };
  return true;
}

// ========== PAYHERO HELPERS ==========
function getPayHeroAuthHeader() {
  const username = process.env.PAYHERO_API_USERNAME;
  const password = process.env.PAYHERO_API_PASSWORD;
  if (!username || !password) {
    throw new Error('PayHero API credentials are not configured');
  }
  return `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`;
}

function payHeroBaseUrl() {
  return (process.env.PAYHERO_BASE_URL || 'https://backend.payhero.co.ke').replace(/\/$/, '');
}

function normalizePhone(phone) {
  // PayHero accepts Kenyan local or international mobile format.
  let msisdn = String(phone || '').trim().replace(/[\s()-]/g, '').replace(/^\+/, '');
  if (/^0[17]\d{8}$/.test(msisdn)) msisdn = '254' + msisdn.substring(1);
  else if (/^[17]\d{8}$/.test(msisdn)) msisdn = '254' + msisdn;
  return msisdn;
}

function isValidKenyanMobile(phone) {
  return /^254[17]\d{8}$/.test(normalizePhone(phone));
}

function phonesMatch(a, b) {
  const na = normalizePhone(a);
  const nb = normalizePhone(b);
  return Boolean(na && nb && na === nb);
}

async function getPayHeroTransactionStatus(reference) {
  const response = await axios.get(`${payHeroBaseUrl()}/api/v2/transaction-status`, {
    params: { reference },
    headers: { Authorization: getPayHeroAuthHeader() },
    timeout: 15000
  });
  return response.data;
}

// ========== ROUTES ==========

app.get('/api/health', (req, res) => {
  res.json({ ok: true, fee: APPLICATION_FEE_KES, time: new Date().toISOString() });
});

app.get('/api/hospitals/:region', (req, res) => {
  res.json(hospitalsByRegion[req.params.region] || []);
});

app.get('/api/positions', (req, res) => {
  res.json(positions);
});

app.get('/api/config', (req, res) => {
  res.json({
    applicationFeeKes: APPLICATION_FEE_KES,
    currency: 'KES'
  });
});

// --- PAYHERO STK PUSH ---
app.post('/api/stk-push', upload.fields([
  { name: 'cv', maxCount: 1 },
  { name: 'coverLetter', maxCount: 1 }
]), async (req, res) => {
  try {
    const data = req.body;
    const phone = String(data.phone || '').trim();

    if (!isValidKenyanMobile(phone)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Kenyan mobile number. Use 07XXXXXXXX or 01XXXXXXXX.'
      });
    }
    if (!req.files?.cv || !req.files?.coverLetter) {
      return res.status(400).json({ success: false, message: 'CV and Cover Letter are required' });
    }

    const msisdn = normalizePhone(phone);
    const callbackUrl = process.env.PAYHERO_CALLBACK_URL;
    const channelId = Number(process.env.PAYHERO_CHANNEL_ID || 1828680);
    if (!callbackUrl || !callbackUrl.startsWith('https://')) {
      return res.status(503).json({ success: false, message: 'PayHero callback URL is not configured as a public HTTPS URL.' });
    }
    if (!Number.isInteger(channelId) || channelId <= 0) {
      return res.status(503).json({ success: false, message: 'PayHero channel ID is not configured correctly.' });
    }

    const externalReference = `HJOB-${uuidv4().replace(/-/g, '').slice(0, 16).toUpperCase()}`;
    const formSnapshot = {
      ...data,
      phone: msisdn,
      cvPath: req.files.cv[0].filename,
      coverLetterPath: req.files.coverLetter[0].filename,
      amount: APPLICATION_FEE_KES,
      createdAt: new Date().toISOString(),
      externalReference,
      payHeroReference: null,
      merchantRequestID: null
    };

    try {
      const payload = {
        amount: APPLICATION_FEE_KES,
        phone_number: msisdn,
        channel_id: channelId,
        provider: process.env.PAYHERO_PROVIDER || 'm-pesa',
        external_reference: externalReference,
        customer_name: String(data.fullName || '').slice(0, 100),
        callback_url: callbackUrl
      };
      const response = await axios.post(`${payHeroBaseUrl()}/api/v2/payments`, payload, {
        headers: {
          Authorization: getPayHeroAuthHeader(),
          'Content-Type': 'application/json'
        },
        timeout: 20000
      });

      const result = response.data || {};
      const checkoutId = result.CheckoutRequestID || result.checkout_request_id;
      const payHeroReference = result.reference || result.Reference;
      if (!result.success || !checkoutId || !payHeroReference) {
        console.error('[PAYHERO_STK_INVALID_RESPONSE]', JSON.stringify({
          httpStatus: response.status,
          success: result.success,
          hasCheckoutId: Boolean(checkoutId),
          hasReference: Boolean(payHeroReference)
        }));
        return res.status(502).json({ success: false, message: 'PayHero did not return a complete payment reference. Please retry or contact support.' });
      }

      formSnapshot.payHeroReference = payHeroReference;
      formSnapshot.checkoutRequestID = checkoutId;
      formSnapshot.paymentStatus = 'PENDING';
      pendingPayments[checkoutId] = formSnapshot;
      savePending();

      return res.json({
        success: true,
        message: 'M-Pesa payment request sent. Enter your M-Pesa PIN to complete payment.',
        checkoutRequestID: checkoutId,
        amount: APPLICATION_FEE_KES
      });
    } catch (payHeroErr) {
      console.error('[PAYHERO_STK_FAILURE]', JSON.stringify({
        httpStatus: payHeroErr.response?.status || null,
        response: payHeroErr.response?.data || null,
        code: payHeroErr.code || null,
        message: payHeroErr.message
      }));
      return res.status(502).json({
        success: false,
        message: 'PayHero could not initiate the M-Pesa payment. Please try again.',
        httpStatus: payHeroErr.response?.status || null
      });
    }
  } catch (err) {
    console.error('[PAYHERO_ROUTE_ERROR]', err.message);
    return res.status(500).json({ success: false, message: 'Unable to initiate payment. Please try again.' });
  }
});

// PayHero payment callback. A callback alone never marks an application paid:
// the transaction is confirmed against PayHero's transaction-status endpoint.
app.post('/api/payhero/callback', async (req, res) => {
  // Acknowledge promptly; verification continues server-side.
  res.status(200).json({ received: true });

  try {
    const body = req.body || {};
    const result = body.response || body.data || body;
    const checkoutId = result.CheckoutRequestID || result.checkout_request_id;
    const externalReference = result.ExternalReference || result.external_reference;
    const pendingEntry = checkoutId ? pendingPayments[checkoutId] : null;
    const matched = pendingEntry || Object.entries(pendingPayments).find(([, item]) => item.externalReference === externalReference)?.[1];
    const matchedCheckoutId = checkoutId && pendingPayments[checkoutId]
      ? checkoutId
      : Object.keys(pendingPayments).find(id => pendingPayments[id].externalReference === externalReference);

    if (!matched || !matchedCheckoutId) {
      console.log('[PAYHERO_CALLBACK_UNKNOWN]', JSON.stringify({ hasCheckoutId: Boolean(checkoutId), hasExternalReference: Boolean(externalReference) }));
      return;
    }
    if (externalReference && matched.externalReference !== externalReference) {
      console.warn('[PAYHERO_CALLBACK_REFERENCE_MISMATCH]');
      return;
    }

    const resultCode = result.ResultCode ?? result.result_code;
    const status = String(result.Status || result.status || '').toUpperCase();
    if ((resultCode !== undefined && Number(resultCode) !== 0) || ['FAILED', 'CANCELLED', 'FAILURE'].includes(status)) {
      delete pendingPayments[matchedCheckoutId];
      savePending();
      console.log('[PAYHERO_PAYMENT_NOT_SUCCESSFUL]', matchedCheckoutId);
      return;
    }

    const amount = Number(result.Amount ?? result.amount);
    const callbackPhone = result.Phone || result.phone || result.PhoneNumber || result.phone_number;
    const receipt = result.MpesaReceiptNumber || result.mpesa_receipt_number || result.provider_reference || result.ProviderReference;
    if (amount !== APPLICATION_FEE_KES || !receipt || (callbackPhone && !phonesMatch(callbackPhone, matched.phone))) {
      console.warn('[PAYHERO_CALLBACK_VALIDATION_FAILED]', JSON.stringify({
        amountMatches: amount === APPLICATION_FEE_KES,
        hasReceipt: Boolean(receipt),
        phoneMatches: callbackPhone ? phonesMatch(callbackPhone, matched.phone) : null
      }));
      return;
    }

    const verified = await getPayHeroTransactionStatus(matched.payHeroReference);
    if (String(verified.status || '').toUpperCase() !== 'SUCCESS' || verified.success !== true) {
      console.log('[PAYHERO_CALLBACK_NOT_YET_VERIFIED]', matchedCheckoutId, verified.status || 'unknown');
      return;
    }
    const verifiedReceipt = verified.provider_reference || verified.third_party_reference || receipt;
    if (applications.some(a => a.mpesaCode === verifiedReceipt)) {
      delete pendingPayments[matchedCheckoutId];
      savePending();
      return;
    }

    await completeApplication(matchedCheckoutId, verifiedReceipt, {
      amount: APPLICATION_FEE_KES,
      phone: callbackPhone || matched.phone,
      merchantRequestID: result.MerchantRequestID || null
    });
  } catch (err) {
    console.error('[PAYHERO_CALLBACK_PROCESSING_ERROR]', err.message);
  }
});

// Retain the original frontend polling contract. If PayHero's callback is delayed,
// query PayHero directly and complete only after its API reports SUCCESS.
app.get('/api/payment-status/:checkoutId', async (req, res) => {
  const checkoutId = req.params.checkoutId;
  const appRec = applications.find(a => a.checkoutRequestID === checkoutId);
  if (appRec) {
    return res.json({
      status: 'completed',
      refNumber: appRec.refNumber,
      interviewDate: appRec.interviewDate,
      interviewTime: appRec.interviewTime,
      letterUrl: `/api/letter/${appRec.refNumber}?token=${appRec.downloadToken}`,
      amount: appRec.amount,
      mpesaCode: appRec.mpesaCode
    });
  }

  const pending = pendingPayments[checkoutId];
  if (!pending) return res.json({ status: 'not_found', message: 'Payment has not been confirmed yet. Please check again or retry.' });

  try {
    const transaction = await getPayHeroTransactionStatus(pending.payHeroReference);
    const transactionStatus = String(transaction.status || '').toUpperCase();
    if (transactionStatus === 'SUCCESS' && transaction.success === true) {
      const receipt = transaction.provider_reference || transaction.third_party_reference;
      if (receipt) {
        await completeApplication(checkoutId, receipt, { amount: APPLICATION_FEE_KES, phone: pending.phone });
        const completed = applications.find(a => a.checkoutRequestID === checkoutId);
        if (completed) {
          return res.json({
            status: 'completed',
            refNumber: completed.refNumber,
            interviewDate: completed.interviewDate,
            interviewTime: completed.interviewTime,
            letterUrl: `/api/letter/${completed.refNumber}?token=${completed.downloadToken}`,
            amount: completed.amount,
            mpesaCode: completed.mpesaCode
          });
        }
      }
    }
    if (['FAILED', 'CANCELLED'].includes(transactionStatus)) {
      delete pendingPayments[checkoutId];
      savePending();
      return res.json({ status: 'failed', message: 'Payment was not completed. You can try again.' });
    }
  } catch (err) {
    console.warn('[PAYHERO_STATUS_CHECK_FAILED]', err.response?.status || '', err.message);
  }

  return res.json({ status: 'pending', message: 'Payment is still being confirmed. Please wait.' });
});

// Secure letter download – requires valid token and paid status
app.get('/api/letter/:refNumber', (req, res) => {
  const { refNumber } = req.params;
  const token = req.query.token || '';
  const appRec = applications.find(a => a.refNumber === refNumber);

  if (!appRec) {
    return res.status(404).json({ success: false, message: 'Document not found' });
  }
  if (appRec.paymentStatus !== 'PAID') {
    return res.status(403).json({ success: false, message: 'Payment has not been confirmed. Document unavailable.' });
  }
  if (!token || token !== appRec.downloadToken) {
    return res.status(403).json({ success: false, message: 'Unauthorized document access' });
  }

  const filepath = path.join(LETTERS_DIR, `${refNumber}.pdf`);
  if (!fs.existsSync(filepath)) {
    return res.status(404).json({ success: false, message: 'Document file missing' });
  }

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${refNumber}.pdf"`);
  fs.createReadStream(filepath).pipe(res);
});

// Protected upload download (admin or via letter flow – admin only for CV/cover)
app.get('/api/uploads/:filename', (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  const filename = path.basename(req.params.filename);
  const filepath = path.join(UPLOADS_DIR, filename);
  if (!fs.existsSync(filepath)) {
    return res.status(404).json({ success: false, message: 'File not found' });
  }
  res.download(filepath);
});

// Complete application after verified successful payment
async function completeApplication(checkoutId, mpesaCode, meta = {}) {
  const data = pendingPayments[checkoutId];
  if (!data) return null;

  // Idempotency
  if (applications.some(a => a.checkoutRequestID === checkoutId || a.mpesaCode === mpesaCode)) {
    delete pendingPayments[checkoutId];
    savePending();
    return applications.find(a => a.checkoutRequestID === checkoutId || a.mpesaCode === mpesaCode);
  }

  applicationCounter++;
  saveCounter();
  const regionCode = (data.region || 'GEN').substring(0, 3).toUpperCase();
  const refNumber = `APP-${regionCode}-2026-${String(applicationCounter).padStart(5, '0')}`;
  const downloadToken = crypto.randomBytes(24).toString('hex');

  // Interview date: 7–12 days ahead, weekday (UNCHANGED logic)
  let interviewDate = moment().add(9, 'days');
  while (interviewDate.day() === 0 || interviewDate.day() === 6) {
    interviewDate.add(1, 'day');
  }

  const application = {
    id: uuidv4(),
    refNumber,
    checkoutRequestID: checkoutId,
    merchantRequestID: meta.merchantRequestID || data.merchantRequestID || null,
    fullName: data.fullName,
    phone: data.phone,
    email: data.email,
    nationalId: data.nationalId || '',
    region: data.region,
    hospital: data.hospital,
    position: data.position,
    residence: data.residence || '',
    experience: data.experience || '',
    qualification: data.qualification || '',
    notes: data.notes || '',
    cvPath: data.cvPath,
    coverLetterPath: data.coverLetterPath,
    amount: APPLICATION_FEE_KES,
    mpesaCode,
    paymentStatus: 'PAID',
    paidAt: new Date().toISOString(),
    interviewDate: interviewDate.format('dddd, D MMMM YYYY'),
    interviewTime: '9:00 AM – 12:00 PM',
    downloadToken,
    createdAt: data.createdAt || new Date().toISOString()
  };

  applications.push(application);
  delete pendingPayments[checkoutId];
  saveApplications();
  savePending();

  const pdfPath = await generateHospitalLetter(application);
  await sendConfirmationEmail(application, pdfPath);

  console.log(`Application completed: ${refNumber} (receipt ${mpesaCode})`);
  return application;
}

// ========== PROFESSIONAL HOSPITAL-BRANDED PDF ==========
function generateHospitalLetter(appData) {
  return new Promise((resolve, reject) => {
    const brand = hospitalBranding[appData.hospital] || {
      name: appData.hospital,
      color: '#1a5276',
      address: 'Kenya',
      phone: '',
      email: 'hr@hospital.co.ke'
    };

    const doc = new PDFDocument({ margin: 50, size: 'A4' });
    const filename = `${appData.refNumber}.pdf`;
    const filepath = path.join(LETTERS_DIR, filename);
    const stream = fs.createWriteStream(filepath);
    doc.pipe(stream);

    const primary = brand.color;
    const pageWidth = 595;
    const contentWidth = 495;

    // ===== HEADER BAND =====
    doc.rect(0, 0, pageWidth, 88).fill(primary);
    doc.fillColor('#FFFFFF').fontSize(15).font('Helvetica-Bold')
       .text(brand.name.toUpperCase(), 50, 22, { width: contentWidth, align: 'left' });
    doc.fontSize(9).font('Helvetica')
       .text('Human Resources Department  •  Recruitment Office', 50, 44);
    doc.fontSize(8)
       .text(`${brand.address}  |  ${brand.phone}`, 50, 60);

    // Thin accent line under header
    doc.rect(0, 88, pageWidth, 3).fill('#e8e8e8');

    // ===== DOCUMENT TITLE =====
    let y = 110;
    doc.fillColor('#111111').fontSize(12).font('Helvetica-Bold')
       .text('APPLICATION CONFIRMATION & INTERVIEW INVITATION', 50, y, { width: contentWidth, align: 'center' });
    y += 16;
    doc.fontSize(9).font('Helvetica').fillColor('#555555')
       .text('This document also serves as your official payment receipt', 50, y, { width: contentWidth, align: 'center' });
    y += 22;

    // Reference box
    doc.roundedRect(50, y, contentWidth, 32, 4).fill('#f4f6f7');
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold')
       .text(`Reference Number: ${appData.refNumber}`, 60, y + 9);
    doc.fillColor('#333333').font('Helvetica').fontSize(9)
       .text(`Date Issued: ${moment().format('D MMMM YYYY')}`, 340, y + 10);
    y += 48;

    // ===== CANDIDATE DETAILS =====
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold').text('CANDIDATE DETAILS', 50, y);
    y += 16;
    doc.moveTo(50, y).lineTo(545, y).strokeColor(primary).lineWidth(1.2).stroke();
    y += 14;

    doc.fillColor('#111111').font('Helvetica').fontSize(10);
    const leftCol = [
      ['Full Name', appData.fullName],
      ['Phone Number', appData.phone],
      ['Email', appData.email],
      ['National ID / Passport', appData.nationalId || 'Not provided']
    ];
    const rightCol = [
      ['Region', appData.region],
      ['Hospital', appData.hospital],
      ['Position Applied', appData.position],
      ['Residence', appData.residence || 'Not provided']
    ];

    leftCol.forEach((row, i) => {
      doc.font('Helvetica-Bold').text(row[0] + ':', 50, y + (i * 16));
      doc.font('Helvetica').text(String(row[1]), 165, y + (i * 16), { width: 140 });
    });
    rightCol.forEach((row, i) => {
      doc.font('Helvetica-Bold').text(row[0] + ':', 320, y + (i * 16));
      doc.font('Helvetica').text(String(row[1]), 420, y + (i * 16), { width: 125 });
    });
    y += 78;

    // ===== PAYMENT RECEIPT =====
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold').text('PAYMENT RECEIPT', 50, y);
    y += 16;
    doc.moveTo(50, y).lineTo(545, y).strokeColor(primary).lineWidth(1.2).stroke();
    y += 14;

    doc.fillColor('#111111').fontSize(10);
    doc.font('Helvetica-Bold').text('Amount Paid:', 50, y);
    doc.font('Helvetica').text(`KSh ${APPLICATION_FEE_KES.toLocaleString('en-KE')}.00`, 160, y);
    doc.font('Helvetica-Bold').text('Payment Method:', 320, y);
    doc.font('Helvetica').text('M-Pesa (STK Push)', 420, y);
    y += 16;
    doc.font('Helvetica-Bold').text('M-Pesa Receipt:', 50, y);
    doc.font('Helvetica').text(appData.mpesaCode, 160, y);
    doc.font('Helvetica-Bold').text('Payment Date:', 320, y);
    doc.font('Helvetica').text(moment(appData.paidAt).format('D MMM YYYY, h:mm A'), 420, y);
    y += 16;
    doc.font('Helvetica-Bold').text('Status:', 50, y);
    doc.fillColor('#006600').font('Helvetica-Bold').text('SUCCESSFULLY RECEIVED', 160, y);
    y += 20;
    doc.fillColor('#555555').fontSize(8).font('Helvetica')
       .text(`This letter is your official receipt for the non-refundable interview booking fee of Kenya Shillings One Thousand Two Hundred Only (KSh ${APPLICATION_FEE_KES}).`, 50, y, { width: contentWidth });
    y += 28;

    // ===== INTERVIEW DETAILS =====
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold').text('INTERVIEW DETAILS', 50, y);
    y += 16;
    doc.moveTo(50, y).lineTo(545, y).strokeColor(primary).lineWidth(1.2).stroke();
    y += 12;

    doc.fillColor('#111111').fontSize(10).font('Helvetica')
       .text('Your application has been successfully received and processed by our recruitment team.', 50, y, { width: contentWidth });
    y += 18;

    doc.roundedRect(50, y, contentWidth, 58, 4).fill('#fef9e7');
    doc.fillColor('#111111').font('Helvetica-Bold').fontSize(10)
       .text(`Interview Date:   ${appData.interviewDate}`, 65, y + 12);
    doc.text(`Interview Time:   ${appData.interviewTime}`, 65, y + 28);
    doc.font('Helvetica').text(`Venue:   Human Resources Department, ${brand.name}`, 65, y + 42, { width: 460 });
    y += 72;

    doc.fontSize(9).fillColor('#333333')
       .text('Mode: In-person  •  Please arrive 30 minutes early. You will receive an SMS/email reminder 24 hours before the interview.', 50, y, { width: contentWidth });
    y += 24;

    // ===== WHAT TO BRING =====
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold').text('WHAT TO BRING TO THE INTERVIEW', 50, y);
    y += 14;
    doc.moveTo(50, y).lineTo(545, y).strokeColor(primary).lineWidth(1.2).stroke();
    y += 12;

    doc.fillColor('#111111').font('Helvetica').fontSize(9);
    const items = [
      '1. This confirmation letter (printed)',
      '2. Original National ID or Passport + one photocopy',
      '3. Updated Curriculum Vitae (CV)',
      '4. Cover Letter',
      '5. Original academic certificates & transcripts + photocopies',
      '6. Professional registration certificates (Nursing Council, KMPDC, etc.) if applicable',
      '7. Two recent passport-size photographs',
      '8. Any other supporting documents relevant to the position'
    ];
    items.forEach(item => {
      doc.text(item, 55, y);
      y += 13;
    });
    y += 10;

    // ===== IMPORTANT NOTES =====
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold').text('IMPORTANT NOTES', 50, y);
    y += 14;
    doc.moveTo(50, y).lineTo(545, y).strokeColor(primary).lineWidth(1.2).stroke();
    y += 12;

    doc.fillColor('#111111').fontSize(8).font('Helvetica');
    const notes = [
      '• Please dress formally / smart casual.',
      `• This interview booking fee of KSh ${APPLICATION_FEE_KES} is non-refundable.`,
      '• Failure to attend the scheduled interview without prior written notice may result in your application being closed.',
      '• Keep this letter safely — it is your official proof of application and payment.',
      '• For any enquiries, contact the hospital HR office using the details at the top of this letter.'
    ];
    notes.forEach(n => {
      doc.text(n, 50, y, { width: contentWidth });
      y += 12;
    });
    y += 14;

    // ===== CLOSING =====
    doc.fontSize(10).fillColor('#111111').text('We look forward to meeting you.', 50, y);
    y += 22;

    doc.font('Helvetica-Bold').text('Authorised by:', 50, y);
    y += 28;
    doc.moveTo(50, y).lineTo(200, y).strokeColor('#333333').stroke();
    y += 8;
    doc.font('Helvetica').fontSize(9)
       .text('Recruitment Administrator', 50, y)
       .text('Human Resources Department', 50, y + 12)
       .text(brand.name, 50, y + 24);

    // Footer
    doc.fontSize(7).fillColor('#888888')
       .text('This is a computer-generated document issued upon successful payment verification. It is valid without a physical signature.', 50, 780, { align: 'center', width: contentWidth });
    doc.text(`Page 1 of 1  •  ${appData.refNumber}`, 50, 792, { align: 'center', width: contentWidth });

    doc.end();
    stream.on('finish', () => resolve(filepath));
    stream.on('error', reject);
  });
}

// ========== EMAIL ==========
async function sendConfirmationEmail(appData, pdfPath) {
  if (!process.env.SMTP_HOST) {
    console.log(`[EMAIL SIMULATED] To: ${appData.email} | Ref: ${appData.refNumber}`);
    return;
  }
  try {
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: process.env.SMTP_PORT || 587,
      secure: false,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });
    await transporter.sendMail({
      from: `"${appData.hospital} Recruitment" <${process.env.SMTP_USER}>`,
      to: appData.email,
      subject: `Interview Booking Confirmed – ${appData.refNumber} | ${appData.hospital}`,
      text: `Dear ${appData.fullName},\n\nYour interview booking at ${appData.hospital} has been confirmed after successful payment of KSh ${APPLICATION_FEE_KES}.\n\nReference: ${appData.refNumber}\nInterview: ${appData.interviewDate} at ${appData.interviewTime}\nM-Pesa Receipt: ${appData.mpesaCode}\n\nPlease find attached your official confirmation letter and payment receipt.\n\nBest regards,\nHuman Resources\n${appData.hospital}`,
      attachments: [{ filename: `${appData.refNumber}.pdf`, path: pdfPath }]
    });
  } catch (err) {
    console.error('Email error:', err.message);
  }
}

// ========== ADMIN ==========
app.get('/api/admin/applications', (req, res) => {
  if (!checkAdminAuth(req, res)) return;
  res.json({
    success: true,
    total: applications.length,
    applications: applications.map(a => ({
      refNumber: a.refNumber,
      fullName: a.fullName,
      phone: a.phone,
      email: a.email,
      region: a.region,
      hospital: a.hospital,
      position: a.position,
      amount: a.amount,
      mpesaCode: a.mpesaCode,
      paymentStatus: a.paymentStatus,
      paidAt: a.paidAt,
      interviewDate: a.interviewDate,
      interviewTime: a.interviewTime,
      cvPath: a.cvPath,
      coverLetterPath: a.coverLetterPath,
      letterUrl: `/api/letter/${a.refNumber}?token=${a.downloadToken}`
    })).reverse()
  });
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start
app.listen(PORT, () => {
  console.log(`\nHospital Jobs Portal running at http://localhost:${PORT}`);
  console.log(`  Admin panel: http://localhost:${PORT}/admin`);
  console.log(`  Application fee: KSh ${APPLICATION_FEE_KES}`);
  console.log(`  Data dir: ${DATA_DIR}`);
  if (!process.env.PAYHERO_API_USERNAME || !process.env.PAYHERO_API_PASSWORD) {
    console.log('  PayHero credentials are not configured; live payments are disabled.\n');
  } else {
    console.log('  Payment provider: PayHero (M-Pesa)\n');
  }
});
