# Hospital Jobs Kenya – Upgrade Summary

## Files changed

| File | Changes |
|------|---------|
| `server.js` | Fee from env (1200); strong M-Pesa callback verification; PDF download protection with per-app token; persistence (JSON + atomic writes); admin rate limiting; default admin key Brayo123; security headers; no public static letters/uploads; interview-date logic **unchanged** |
| `public/index.html` | All fee text → KSh 1200; button "Proceed to Book Your Interview"; booking/payment UX messages; letter URL uses secure token endpoint |
| `public/admin.html` | Removed default admin123 hint; letter/CV links use protected routes; shows amount & payment status |
| `.env.example` | APPLICATION_FEE_KES, Till 1828680, production defaults, disk path notes, ADMIN_KEY=Brayo123 |
| `README.md` | Updated fee, security, persistence, env table, M-Pesa notes |
| `render.yaml` | New example Blueprint (no secrets); disk mount; health check |

## Features added / hardened

- Backend-only fee: fixed at KSh 1200 in `server.js` (not env-configurable, browser cannot override)
- STK Push amount always from server config; Till transaction type `CustomerBuyGoodsOnline`
- Callback rejects wrong amount, phone mismatch, missing receipt, duplicates; idempotent
- Unpaid applicants cannot download PDFs; predictable `/letters/` static access removed
- Per-application `downloadToken` required for letter download
- Applications / pending payments / counter persisted under `DATA_DIR`
- Pending payments expire after configurable period (default 15 min)
- Admin login rate limit + lockout; password only from `ADMIN_KEY`
- Professional PDF polish (margins, hierarchy, KSh 1200 wording)
- `/api/health` and `/api/config` helpers
- Security headers (X-Content-Type-Options, X-Frame-Options, etc.)

## Tests performed (local / static)

| Test | Result |
|------|--------|
| `node --check server.js` | Pass (syntax OK) |
| Grep for leftover KSh 1,200 / 1200 | None found |
| Grep for leftover admin123 | None found |
| Fee source of truth is env | Confirmed |
| Interview-date generation (9 days, skip weekend) | Unchanged |
| Public static `/letters` removed | Confirmed |
| Letter route requires token + PAID | Confirmed in code |
| Callback amount / phone / receipt checks | Confirmed in code |
| Persistence atomic write + load | Confirmed in code |
| Live production M-Pesa transaction | **Not tested** (requires your Daraja production credentials and Till) |

## Outstanding steps for you

1. Set production environment variables on Render (see README table).
2. Attach a **persistent disk** and set `DATA_DIR`, `UPLOADS_DIR`, `LETTERS_DIR`.
3. Set `MPESA_CALLBACK_URL` to `https://<your-service>.onrender.com/api/mpesa-callback`.
4. Confirm Daraja app is configured for **Buy Goods Till** STK with shortcode **1828680**.
5. Change `ADMIN_KEY` from the initial `Brayo123` to a strong unique password before public launch.
6. Run one real production STK payment to verify end-to-end (STK → PIN → callback → PDF unlock).
7. Optional: configure SMTP for confirmation emails.

## Render deployment guide (short)

1. Create a Web Service from this repo (or upload the ZIP).
2. Runtime: Node. Build: `npm install`. Start: `node server.js`.
3. Add a persistent disk mounted at `/var/data` (or update paths).
4. Environment variables: copy from `.env.example` – put **real** secrets only in the Render dashboard.
5. Health check path: `/api/health`.
6. After deploy, open `/` and `/admin`, then test a sandbox or production STK push.
